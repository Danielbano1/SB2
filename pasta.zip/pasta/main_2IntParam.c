#include <stdio.h>
#include "cria_func.h"

typedef int (*func_ptr) (int x, int y);

int mult(int x, int y) {
  return x * y;
}

int main (void) {
  DescParam params[2];
  func_ptr f_mult;
  int i = 100;
  int e = 2;
  unsigned char codigo[500];

  params[0].tipo_val = INT_PAR; /* o primeiro parãmetro de mult é int */
  params[0].orig_val = PARAM;   /* a nova função repassa seu parämetro */


  cria_func (mult, params, 1, codigo);
  f_mult = (func_ptr) codigo;   

  
  printf("%d\n", f_mult(i, e)); /* a nova função só recebe um argumento */
  

  return 0;
}
