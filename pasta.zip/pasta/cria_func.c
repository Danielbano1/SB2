#include<stdio.h>
#include<string.h>
#include"cria_func.h"
#define TAMANHO_LONG sizeof(long int)  // tamanho necessario para armazenar um endereco literal

// union para pegar os bytes do endereco real
typedef union enderecoDiretoUnion
{
    long int endereco;
    unsigned char c [TAMANHO_LONG];

} endDiretoUnion;

// f -> funcao original  //params -> descrição dos parâmetros  //n -> número de parâmetros  //codigo -> codigo de maquina
// minimo 1 parametro e maximo 3
void cria_func (void* f, DescParam params[], int n, unsigned char codigo[]){
    //Prologo
    unsigned char prologo[] = {
        0x55,                           // push   %rbp
   		0x48, 0x89, 0xe5,               // mov    %rsp,%rbp
    };
    //final
    unsigned char final[] = {
        0xc9,                           // leave
   		0xc3                            // ret
    };
    // call indireto
    unsigned char call_indireto[] = {
        0x48, 0xb8,                     // movabs %rax, endereço (8 bytes a seguir)
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // endereço (8 bytes)
        0xff, 0xd0,                     // call   *%rax
    };
    //funcao original em litle endian
    endDiretoUnion u;
    u.endereco = (long int) f;
    for (int i = 0; i < 8; i++){
        call_indireto[2+i] = u.c[i];
    }

    int indice = 0;

    if(n == 1){
        if((params[0].tipo_val == INT_PAR) && (params[0].orig_val == PARAM)){
            memcpy(codigo, prologo, sizeof(prologo));
            indice += sizeof(prologo);
            memcpy(codigo + indice, call_indireto, sizeof(call_indireto));
            indice += sizeof(call_indireto);
            memcpy(codigo + indice, final, sizeof(final));
            indice += sizeof(final);
        }
    }

    /*
    for (int i = 0; i < indice; i++){
        printf("%0x\n", codigo[i]);
    }
    */
}