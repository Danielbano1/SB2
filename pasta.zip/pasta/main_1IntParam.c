#include <stdio.h>
#include "cria_func.h"

typedef int (*func_ptr) (int x);

int foo(int x, int y) {
  return x;
}

int main (void) {
  DescParam params[2];
  func_ptr f_foo;
  int i = 100;
  unsigned char codigo[500];

  params[0].tipo_val = INT_PAR; /* o primeiro parãmetro de foo é int */
  params[0].orig_val = PARAM;   /* a nova função repassa seu parämetro */


  cria_func (foo, params, 1, codigo);
  f_foo = (func_ptr) codigo;   

  
  printf("%d\n", f_foo(i)); /* a nova função só recebe um argumento */
  

  return 0;
}
